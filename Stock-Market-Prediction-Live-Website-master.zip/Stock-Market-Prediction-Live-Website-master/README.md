# Stock-Market-Prediction-Live-Website
Displays the information of a company given through nasdaq code displays information of closing price , volume traded and a increase and decrease in stock price and predicts the stock through this information.Algorithm has been published in quantopian.
www.stockpredict.tech

![sd1](https://user-images.githubusercontent.com/22158287/31752325-3e020984-b458-11e7-8b6f-c104f1a773ea.JPG)
![s2](https://user-images.githubusercontent.com/22158287/31752343-59c47f76-b458-11e7-8237-5ff3d9321382.JPG)
![s](https://user-images.githubusercontent.com/22158287/31752347-639cc81e-b458-11e7-8505-f6c833bde042.JPG)
![s4](https://user-images.githubusercontent.com/22158287/31752358-70d53656-b458-11e7-89ec-81acb20d39a1.JPG)
![s3](https://user-images.githubusercontent.com/22158287/31752365-7a3c3adc-b458-11e7-88c6-f7021e57337d.JPG)
